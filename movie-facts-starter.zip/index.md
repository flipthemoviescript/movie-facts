
# 🎬 Movie Facts — Curated by FlipTheMovieScript.com

Welcome! This mini site is a **clean, browsable index of movie facts and behind‑the‑scenes trivia**.  
Each page includes a short preview and a link to the full story on FlipTheMovieScript.com.

## Featured
- [Sylvester Stallone — Quick Trivia](actors/stallone-trivia.md)
- [Goodfellas — Behind the Scenes](films/goodfellas-facts.md)
- [Arnold Schwarzenegger — Quick Facts](actors/arnold-trivia.md)

> Want more? Visit **[FlipTheMovieScript.com](https://flipthemoviescript.com)** for deep dives.
