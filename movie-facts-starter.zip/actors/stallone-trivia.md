
# Sylvester Stallone — Quick Trivia

- Stallone was born with partial facial paralysis, shaping his iconic speaking style.  
  👉 **Full story:** [Stallone’s facial paralysis from birth injury](https://flipthemoviescript.com/sylvester-stallone-face-paralysis-birth-injury-story/)

- Before *Rocky*, he briefly worked in adult film to make ends meet.  
  👉 **Context & details:** [Stallone’s early adult movie career](https://flipthemoviescript.com/sylvester-stallone-adult-movie-career-before-rocky/)

- During *Rocky IV*, a fight sequence with Dolph Lundgren sent Stallone to the ICU.  
  👉 **What happened:** [Lundgren “put Stallone in the hospital”](https://flipthemoviescript.com/dolph-lundgren-put-sylvester-stallone-in-hospital-rocky-4/)
