
# Goodfellas — Behind the Scenes

- The “Funny how?” scene was famously **improvised** around Joe Pesci’s real nightclub story, then shaped by Scorsese with tight blocking and camera moves.
- Scorsese’s use of **long takes** and needle‑drop soundtrack cues became a template for modern crime films.
- Ray Liotta’s narration was recorded across multiple sessions to refine the film’s rhythm.

👉 **Read more:** (Add your Goodfellas deep‑dive URL here)
